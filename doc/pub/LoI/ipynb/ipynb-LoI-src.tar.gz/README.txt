This IPython notebook LoI.ipynb does not require any additional
programs.
